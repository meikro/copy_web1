<?php

$restricted_ip = ['203.177.158.','123.126.113.','123.126.68.','36.110.147.','180.232.'];

foreach($restricted_ip as $tmp) {
    if (strncmp($tmp, $_SERVER['REMOTE_ADDR'], strlen($tmp)) === 0) {
        header('Location: http://domainwall.cloud.baidu.com/block.html');
        exit;
    }
}